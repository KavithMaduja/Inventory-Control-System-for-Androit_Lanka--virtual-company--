﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DatabaseClassForDealer;
using System.Data.SqlClient;

namespace WindowsMain
{
    public partial class GeneratePickingList : MetroFramework.Forms.MetroForm
    {
        public GeneratePickingList()
        {
            InitializeComponent();
        }

        DatabaseConnector Con1 = new DatabaseConnector();

        /*SqlConnection con;
        SqlDataAdapter da;
        SqlCommand cmd;*/

        string salesOrderNo;

        private void Form1_Load(object sender, EventArgs e)
        {
           
          
        }

        private void btn_ok_Click(object sender, EventArgs e)
        {
            //txt_salesorderno.Text = salesOrderNo;

            try
            {
                DataTable ddt = new DataTable();
                string query = "SELECT soh.salesorderno, c.cusname, c.addressLine1 c.addressLine2,c.addressLine3 FROM salesorderheader soh INNER JOIN customer c ON soh.cusid = c.cusid WHERE soh.salesorderno=3001";
                /*ddt = Con1.getData(query);

                txt_salesorderno.Text = ddt.Rows[0]["salesorderno"].ToString(); 
                txt_cusname.Text = ddt.Rows[0]["cusname"].ToString();
                txt_cusadd.Text = ddt.Rows[0]["addressline1"].ToString();*/

                query = "SELECT st.binno, st.sku, sod.qty ,i.itemname, i.description FROM stocks st INNER JOIN salesorderdetail sod ON st.itemno = sod.itemno INNER JOIN item i ON sod.itemno = i.itemno WHERE sod.salesorderno = 4001";
                ddt = Con1.getData(query);
                DataGridPickingList.DataSource = ddt;
            }
            catch (SqlException Ex)
            {
                MessageBox.Show("A Database Error Occured: " + Ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception Ex)
            {
                MessageBox.Show("An Error Occured: " + Ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void SetSalesOrderNo(string s)
        {
            salesOrderNo = s;
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
