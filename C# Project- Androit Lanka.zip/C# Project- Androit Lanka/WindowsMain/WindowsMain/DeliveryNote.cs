﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsMain
{
    public partial class DeliveryNote : MetroFramework.Forms.MetroForm
    {
        public DeliveryNote()
        {
            InitializeComponent();
        }

        private void DeliveryNote_Load(object sender, EventArgs e)
        {

        }

        private void btn_OK_Click(object sender, EventArgs e)
        {
            /*try
            {
                con.Open();
                da = new SqlDataAdapter("select * from customer", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                txt_CusName.Text = dt.Rows[0]["cusname"].ToString();
                txt_ConFName.Text = dt.Rows[0]["contactFName"].ToString();
                txt_ConLName.Text = dt.Rows[0]["contactLName"].ToString();
                txt_AddL1.Text = dt.Rows[0]["addressline1"].ToString();
                txt_AddL2.Text = dt.Rows[0]["addressLine2"].ToString();
                txt_AdL3.Text = dt.Rows[0]["addressLine3"].ToString();

                da = new SqlDataAdapter("select * from invoiceheader", con);
                DataTable dt1 = new DataTable();
                da.Fill(dt1);
                txt_InvNo.Text = dt1.Rows[0]["invoiceno"].ToString();

                da = new SqlDataAdapter("select * from item ", con);
                DataTable dt2 = new DataTable();

                da.Fill(dt2);
                dataGridView1.DataSource = dt2;
            }
            catch (SqlException)
            {

            }*/

        
    }
    }
}
