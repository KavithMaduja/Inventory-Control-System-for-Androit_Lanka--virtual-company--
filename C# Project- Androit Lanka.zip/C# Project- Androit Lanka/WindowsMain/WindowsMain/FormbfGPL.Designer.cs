﻿namespace WindowsMain
{
    partial class FormbfGPL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_salesorderno = new MetroFramework.Controls.MetroTextBox();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.SuspendLayout();
            // 
            // txt_salesorderno
            // 
            // 
            // 
            // 
            this.txt_salesorderno.CustomButton.Image = null;
            this.txt_salesorderno.CustomButton.Location = new System.Drawing.Point(176, 1);
            this.txt_salesorderno.CustomButton.Name = "";
            this.txt_salesorderno.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txt_salesorderno.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txt_salesorderno.CustomButton.TabIndex = 1;
            this.txt_salesorderno.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txt_salesorderno.CustomButton.UseSelectable = true;
            this.txt_salesorderno.CustomButton.Visible = false;
            this.txt_salesorderno.Lines = new string[0];
            this.txt_salesorderno.Location = new System.Drawing.Point(132, 111);
            this.txt_salesorderno.MaxLength = 32767;
            this.txt_salesorderno.Name = "txt_salesorderno";
            this.txt_salesorderno.PasswordChar = '\0';
            this.txt_salesorderno.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txt_salesorderno.SelectedText = "";
            this.txt_salesorderno.SelectionLength = 0;
            this.txt_salesorderno.SelectionStart = 0;
            this.txt_salesorderno.ShortcutsEnabled = true;
            this.txt_salesorderno.Size = new System.Drawing.Size(198, 23);
            this.txt_salesorderno.TabIndex = 0;
            this.txt_salesorderno.UseSelectable = true;
            this.txt_salesorderno.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txt_salesorderno.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroButton1
            // 
            this.metroButton1.Location = new System.Drawing.Point(174, 151);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(75, 23);
            this.metroButton1.TabIndex = 1;
            this.metroButton1.Text = "Generate";
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.metroButton1_Click);
            // 
            // FormbfGPL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 305);
            this.Controls.Add(this.metroButton1);
            this.Controls.Add(this.txt_salesorderno);
            this.Name = "FormbfGPL";
            this.Text = "(Picking List)";
            this.Load += new System.EventHandler(this.FormbfGPL_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTextBox txt_salesorderno;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}