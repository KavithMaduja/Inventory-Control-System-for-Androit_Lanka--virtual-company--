﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DatabaseClassForDealer;
using System.Data.SqlClient;


namespace WindowsMain
{
    public partial class MainMenu : MetroFramework.Forms.MetroForm
    {
        public MainMenu()
        {
            InitializeComponent();
            metro_panel_placeorder.Visible = false;
            metro_panel_prepareshipment.Visible = false;
            metro_panel_recordstock.Visible = false;
            metro_panel_printinvoices.Visible = false;
            metro_panel_updatestock.Visible = false;         
            filldata();
        }

        SqlConnection con;
        SqlDataAdapter da;
        SqlCommand cmd;

        void filldata()
        {
            try
            {
                con.Open();
                cmd = new SqlCommand("select * from item", con);
                SqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    string sname = dr.GetString(1);
                    cmb_select.Items.Add(sname);
                }

            }
            catch { }


        }

        DatabaseConnector dc1 = new DatabaseConnector();



        public void Reset()
        {
            metro_panel_placeorder.Visible = false;
            metro_panel_placeorder.Location = new System.Drawing.Point(23, 159);
            metro_panel_placeorder.Size = new System.Drawing.Size(200, 100);

            metro_panel_prepareshipment.Visible = false;
            metro_panel_prepareshipment.Location = new System.Drawing.Point(235, 160);
            metro_panel_prepareshipment.Size = new System.Drawing.Size(200, 100);

            metro_panel_recordstock.Visible = false;
            metro_panel_recordstock.Location = new System.Drawing.Point(383, 177);
            metro_panel_recordstock.Size = new System.Drawing.Size(200, 100);

            metro_panel_printinvoices.Visible = false;
            metro_panel_printinvoices.Location = new System.Drawing.Point(780, 208);
            metro_panel_printinvoices.Size = new System.Drawing.Size(173, 130);

            metro_panel_updatestock.Visible = false;
            metro_panel_updatestock.Location = new System.Drawing.Point(753, 228);
            metro_panel_updatestock.Size = new System.Drawing.Size(200, 100);
        }

        private void Main_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'adroit_lanka_dbDataSet1.item' table. You can move, or remove it, as needed.
            this.itemTableAdapter.Fill(this.adroit_lanka_dbDataSet1.item);
            // TODO: This line of code loads data into the 'adroit_lanka_dbDataSet.pickinglistdetail' table. You can move, or remove it, as needed.
            this.pickinglistdetailTableAdapter.Fill(this.adroit_lanka_dbDataSet.pickinglistdetail);

            con = new SqlConnection("Data Source=HIMATH\\HIMATHSQL;Initial Catalog=adroit_lanka_db;Integrated Security=True");

        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            
        }

        private void tl_btn_updatestock_Click(object sender, EventArgs e)
        {
                   
        }

        private void tl_btn_placeorder_Click(object sender, EventArgs e)
        {
                   
        }

        private void metroTile2_Click(object sender, EventArgs e)
        {
            Reset();
            metro_panel_prepareshipment.Visible = true;
            metro_panel_prepareshipment.Location = new System.Drawing.Point(23, 159);
            metro_panel_prepareshipment.Size = new System.Drawing.Size(940, 498);
        }

        private void tl_btn_placeorder_Click_1(object sender, EventArgs e)
        {
            Reset();
            metro_panel_placeorder.Visible = true;
            metro_panel_placeorder.Location = new System.Drawing.Point(23, 159);
            metro_panel_placeorder.Size = new System.Drawing.Size(940, 498);
        }

        private void metroTile3_Click(object sender, EventArgs e)
        {
            Reset();
            metro_panel_recordstock.Visible = true;
            metro_panel_recordstock.Location = new System.Drawing.Point(23, 159);
            metro_panel_recordstock.Size = new System.Drawing.Size(940, 498);
        }

        private void metroTile1_Click_1(object sender, EventArgs e)
        {
            Reset();
            metro_panel_printinvoices.Visible = true;
            metro_panel_printinvoices.Location = new System.Drawing.Point(23, 159);
            metro_panel_printinvoices.Size = new System.Drawing.Size(940, 498);
        }

        private void mt_btn_updtstock_Click(object sender, EventArgs e)
        {
            Reset();
            metro_panel_updatestock.Visible = true;
            metro_panel_updatestock.Location = new System.Drawing.Point(23, 159);
            metro_panel_updatestock.Size = new System.Drawing.Size(940, 498);
        }

        private void metroTile5_Click(object sender, EventArgs e)
        {
            DeliveryNote dn1 = new DeliveryNote();
            dn1.Show();
        }

        private void metroTile4_Click(object sender, EventArgs e)
        {
            Generate_INVOICE inv1 = new Generate_INVOICE();
            inv1.Show();
        }

        private void metroTile6_Click(object sender, EventArgs e)
        {
            try
            {

                dc1.ExecuteQuery("update pickinglistdetail set packedby= '" + txt_pkdby.Text + "', checkedby='" + txt_chkby.Text + "' where pickinglistno= '" + comboBox1.Text + "'");

            }
            catch(SqlException)
            {
                MessageBox.Show("Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btn_search_cus_tele_num_Click(object sender, EventArgs e)
        {
            try
            {

                con.Open();
                da = new SqlDataAdapter("select cusid,cusname,telephone,addressLine1,addressLine2,addressLine3 from customer where telephone=('" + Convert.ToString(txt_enter_cus_tele_num.Text) + "')", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                con.Close();
                dataGrid_cus_detail.DataSource = dt;

            }
            catch (SqlException)
            {

            }
        }

        private void btn_add_qty_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("insert into salesorderdetail values ('" + textBox1.Text + "','" + txt_itemno.Text + "','" + txt_qty.Text + "')", con);
            SqlCommand cmd1 = new SqlCommand("");
            cmd.ExecuteNonQuery();
            dataGrid_qty.ColumnCount = 2;
            dataGrid_qty.Columns[0].Name = "Item Name ";
            dataGrid_qty.Columns[1].Name = "quantity";

            string[] row = new string[] { cmb_select.Text, txt_qty.Text };
            dataGrid_qty.Rows.Add(row);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            da = new SqlDataAdapter("select SO.itemno from salesorderdetail SO inner join item I ON I.itemno=SO.itemno where itemname='" + cmb_select.Text + "'", con);
            DataTable dt = new DataTable();
            da.Fill(dt);
            txt_itemno.Text = dt.Rows[0]["itemno"].ToString();
        }

        private void btn_addcus_Click(object sender, EventArgs e)
        {
            Customer c1 = new Customer();
            c1.setcustp(txt_enter_cus_tele_num.Text);
            c1.ShowDialog();
        }

        private void metro_panel_placeorder_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_exit_Click(object sender, EventArgs e)
        {

        }
    }
}
