﻿namespace WindowsMain
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tasksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.metroTile2 = new MetroFramework.Controls.MetroTile();
            this.metroTile3 = new MetroFramework.Controls.MetroTile();
            this.metro_panel_placeorder = new MetroFramework.Controls.MetroPanel();
            this.btn_addcus = new System.Windows.Forms.Button();
            this.dataGrid_qty = new System.Windows.Forms.DataGridView();
            this.btn_place = new System.Windows.Forms.Button();
            this.metroTile4 = new MetroFramework.Controls.MetroTile();
            this.btn_exit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl_itemno = new System.Windows.Forms.Label();
            this.txt_itemno = new System.Windows.Forms.TextBox();
            this.dataGrid_cus_detail = new System.Windows.Forms.DataGridView();
            this.btn_add_qty = new System.Windows.Forms.Button();
            this.txt_qty = new System.Windows.Forms.TextBox();
            this.lbl_qty = new System.Windows.Forms.Label();
            this.lbi_select_items = new System.Windows.Forms.Label();
            this.cmb_select = new System.Windows.Forms.ComboBox();
            this.itemBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adroit_lanka_dbDataSet1 = new WindowsMain.adroit_lanka_dbDataSet1();
            this.btn_search_cus_tele_num = new System.Windows.Forms.Button();
            this.txt_enter_cus_tele_num = new System.Windows.Forms.TextBox();
            this.lbl_enter_cus_tele_num = new System.Windows.Forms.Label();
            this.metro_panel_prepareshipment = new MetroFramework.Controls.MetroPanel();
            this.button4 = new System.Windows.Forms.Button();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.DataGridPickingList = new System.Windows.Forms.DataGridView();
            this.txt_cusadd = new System.Windows.Forms.TextBox();
            this.txt_cusname = new System.Windows.Forms.TextBox();
            this.txt_salesorderno = new System.Windows.Forms.TextBox();
            this.txt_pickinglistno = new System.Windows.Forms.TextBox();
            this.lbl_cusadd = new System.Windows.Forms.Label();
            this.lbl_cusname = new System.Windows.Forms.Label();
            this.lbl_salesorderno = new System.Windows.Forms.Label();
            this.lbl_pickinglistno = new System.Windows.Forms.Label();
            this.tl_btn_placeorder = new MetroFramework.Controls.MetroTile();
            this.metro_panel_recordstock = new MetroFramework.Controls.MetroPanel();
            this.metroTile6 = new MetroFramework.Controls.MetroTile();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.pickinglistdetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.adroit_lanka_dbDataSet = new WindowsMain.adroit_lanka_dbDataSet();
            this.txt_chkby = new System.Windows.Forms.TextBox();
            this.lbl_chkby = new System.Windows.Forms.Label();
            this.txt_pkdby = new System.Windows.Forms.TextBox();
            this.lbl_pkdby = new System.Windows.Forms.Label();
            this.lbl_pklnum = new System.Windows.Forms.Label();
            this.metro_panel_printinvoices = new MetroFramework.Controls.MetroPanel();
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.button2 = new System.Windows.Forms.Button();
            this.metro_panel_updatestock = new MetroFramework.Controls.MetroPanel();
            this.button3 = new System.Windows.Forms.Button();
            this.mt_btn_updtstock = new MetroFramework.Controls.MetroTile();
            this.pickinglistdetailTableAdapter = new WindowsMain.adroit_lanka_dbDataSetTableAdapters.pickinglistdetailTableAdapter();
            this.itemTableAdapter = new WindowsMain.adroit_lanka_dbDataSet1TableAdapters.itemTableAdapter();
            this.menuStrip1.SuspendLayout();
            this.metro_panel_placeorder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_qty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_cus_detail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adroit_lanka_dbDataSet1)).BeginInit();
            this.metro_panel_prepareshipment.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPickingList)).BeginInit();
            this.metro_panel_recordstock.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pickinglistdetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.adroit_lanka_dbDataSet)).BeginInit();
            this.metro_panel_printinvoices.SuspendLayout();
            this.metro_panel_updatestock.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.tasksToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(20, 60);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(933, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(39, 21);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // tasksToolStripMenuItem
            // 
            this.tasksToolStripMenuItem.Name = "tasksToolStripMenuItem";
            this.tasksToolStripMenuItem.Size = new System.Drawing.Size(51, 21);
            this.tasksToolStripMenuItem.Text = "Tasks";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(47, 21);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Location = new System.Drawing.Point(467, 88);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(147, 61);
            this.metroTile1.TabIndex = 3;
            this.metroTile1.Text = "Print Invoices and \r\nDelivery notes";
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.Click += new System.EventHandler(this.metroTile1_Click_1);
            // 
            // metroTile2
            // 
            this.metroTile2.ActiveControl = null;
            this.metroTile2.Location = new System.Drawing.Point(196, 88);
            this.metroTile2.Name = "metroTile2";
            this.metroTile2.Size = new System.Drawing.Size(117, 61);
            this.metroTile2.Style = MetroFramework.MetroColorStyle.Purple;
            this.metroTile2.TabIndex = 5;
            this.metroTile2.Text = "Prepare \r\nShipment";
            this.metroTile2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.metroTile2.UseSelectable = true;
            this.metroTile2.Click += new System.EventHandler(this.metroTile2_Click);
            // 
            // metroTile3
            // 
            this.metroTile3.ActiveControl = null;
            this.metroTile3.Location = new System.Drawing.Point(333, 88);
            this.metroTile3.Name = "metroTile3";
            this.metroTile3.Size = new System.Drawing.Size(116, 61);
            this.metroTile3.Style = MetroFramework.MetroColorStyle.Purple;
            this.metroTile3.TabIndex = 6;
            this.metroTile3.Text = "Record Stock \r\nHandling Data";
            this.metroTile3.UseSelectable = true;
            this.metroTile3.Click += new System.EventHandler(this.metroTile3_Click);
            // 
            // metro_panel_placeorder
            // 
            this.metro_panel_placeorder.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.metro_panel_placeorder.Controls.Add(this.btn_addcus);
            this.metro_panel_placeorder.Controls.Add(this.dataGrid_qty);
            this.metro_panel_placeorder.Controls.Add(this.btn_place);
            this.metro_panel_placeorder.Controls.Add(this.metroTile4);
            this.metro_panel_placeorder.Controls.Add(this.btn_exit);
            this.metro_panel_placeorder.Controls.Add(this.button1);
            this.metro_panel_placeorder.Controls.Add(this.textBox1);
            this.metro_panel_placeorder.Controls.Add(this.lbl_itemno);
            this.metro_panel_placeorder.Controls.Add(this.txt_itemno);
            this.metro_panel_placeorder.Controls.Add(this.dataGrid_cus_detail);
            this.metro_panel_placeorder.Controls.Add(this.btn_add_qty);
            this.metro_panel_placeorder.Controls.Add(this.txt_qty);
            this.metro_panel_placeorder.Controls.Add(this.lbl_qty);
            this.metro_panel_placeorder.Controls.Add(this.lbi_select_items);
            this.metro_panel_placeorder.Controls.Add(this.cmb_select);
            this.metro_panel_placeorder.Controls.Add(this.btn_search_cus_tele_num);
            this.metro_panel_placeorder.Controls.Add(this.txt_enter_cus_tele_num);
            this.metro_panel_placeorder.Controls.Add(this.lbl_enter_cus_tele_num);
            this.metro_panel_placeorder.HorizontalScrollbarBarColor = true;
            this.metro_panel_placeorder.HorizontalScrollbarHighlightOnWheel = false;
            this.metro_panel_placeorder.HorizontalScrollbarSize = 10;
            this.metro_panel_placeorder.Location = new System.Drawing.Point(20, 166);
            this.metro_panel_placeorder.Name = "metro_panel_placeorder";
            this.metro_panel_placeorder.Size = new System.Drawing.Size(749, 256);
            this.metro_panel_placeorder.TabIndex = 7;
            this.metro_panel_placeorder.VerticalScrollbarBarColor = true;
            this.metro_panel_placeorder.VerticalScrollbarHighlightOnWheel = false;
            this.metro_panel_placeorder.VerticalScrollbarSize = 10;
            this.metro_panel_placeorder.Paint += new System.Windows.Forms.PaintEventHandler(this.metro_panel_placeorder_Paint);
            // 
            // btn_addcus
            // 
            this.btn_addcus.Location = new System.Drawing.Point(325, 375);
            this.btn_addcus.Name = "btn_addcus";
            this.btn_addcus.Size = new System.Drawing.Size(124, 32);
            this.btn_addcus.TabIndex = 37;
            this.btn_addcus.Text = "Add Customer";
            this.btn_addcus.UseVisualStyleBackColor = true;
            this.btn_addcus.Click += new System.EventHandler(this.btn_addcus_Click);
            // 
            // dataGrid_qty
            // 
            this.dataGrid_qty.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_qty.Location = new System.Drawing.Point(35, 295);
            this.dataGrid_qty.Name = "dataGrid_qty";
            this.dataGrid_qty.Size = new System.Drawing.Size(246, 112);
            this.dataGrid_qty.TabIndex = 36;
            // 
            // btn_place
            // 
            this.btn_place.Location = new System.Drawing.Point(325, 413);
            this.btn_place.Name = "btn_place";
            this.btn_place.Size = new System.Drawing.Size(124, 30);
            this.btn_place.TabIndex = 35;
            this.btn_place.Text = "Place";
            this.btn_place.UseVisualStyleBackColor = true;
            // 
            // metroTile4
            // 
            this.metroTile4.ActiveControl = null;
            this.metroTile4.Location = new System.Drawing.Point(400, 179);
            this.metroTile4.Name = "metroTile4";
            this.metroTile4.Size = new System.Drawing.Size(156, 124);
            this.metroTile4.TabIndex = 3;
            this.metroTile4.Text = "Invoice";
            this.metroTile4.UseSelectable = true;
            this.metroTile4.Click += new System.EventHandler(this.metroTile4_Click);
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(35, 424);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(124, 30);
            this.btn_exit.TabIndex = 34;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.btn_exit_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(285, 222);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(34, 23);
            this.button1.TabIndex = 33;
            this.button1.Text = "ok";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(325, 225);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 32;
            // 
            // lbl_itemno
            // 
            this.lbl_itemno.AutoSize = true;
            this.lbl_itemno.Location = new System.Drawing.Point(431, 228);
            this.lbl_itemno.Name = "lbl_itemno";
            this.lbl_itemno.Size = new System.Drawing.Size(41, 13);
            this.lbl_itemno.TabIndex = 31;
            this.lbl_itemno.Text = "item no";
            // 
            // txt_itemno
            // 
            this.txt_itemno.Location = new System.Drawing.Point(507, 225);
            this.txt_itemno.Name = "txt_itemno";
            this.txt_itemno.Size = new System.Drawing.Size(100, 20);
            this.txt_itemno.TabIndex = 30;
            // 
            // dataGrid_cus_detail
            // 
            this.dataGrid_cus_detail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid_cus_detail.Location = new System.Drawing.Point(35, 54);
            this.dataGrid_cus_detail.Name = "dataGrid_cus_detail";
            this.dataGrid_cus_detail.Size = new System.Drawing.Size(579, 119);
            this.dataGrid_cus_detail.TabIndex = 29;
            // 
            // btn_add_qty
            // 
            this.btn_add_qty.Location = new System.Drawing.Point(287, 254);
            this.btn_add_qty.Name = "btn_add_qty";
            this.btn_add_qty.Size = new System.Drawing.Size(107, 30);
            this.btn_add_qty.TabIndex = 28;
            this.btn_add_qty.Text = "Add";
            this.btn_add_qty.UseVisualStyleBackColor = true;
            this.btn_add_qty.Click += new System.EventHandler(this.btn_add_qty_Click);
            // 
            // txt_qty
            // 
            this.txt_qty.Location = new System.Drawing.Point(97, 260);
            this.txt_qty.Name = "txt_qty";
            this.txt_qty.Size = new System.Drawing.Size(184, 20);
            this.txt_qty.TabIndex = 27;
            // 
            // lbl_qty
            // 
            this.lbl_qty.AutoSize = true;
            this.lbl_qty.Location = new System.Drawing.Point(32, 263);
            this.lbl_qty.Name = "lbl_qty";
            this.lbl_qty.Size = new System.Drawing.Size(49, 13);
            this.lbl_qty.TabIndex = 26;
            this.lbl_qty.Text = "Quantity:";
            // 
            // lbi_select_items
            // 
            this.lbi_select_items.AutoSize = true;
            this.lbi_select_items.Location = new System.Drawing.Point(32, 193);
            this.lbi_select_items.Name = "lbi_select_items";
            this.lbi_select_items.Size = new System.Drawing.Size(68, 13);
            this.lbi_select_items.TabIndex = 25;
            this.lbi_select_items.Text = "Select Items:";
            // 
            // cmb_select
            // 
            this.cmb_select.DataSource = this.itemBindingSource;
            this.cmb_select.DisplayMember = "itemname";
            this.cmb_select.FormattingEnabled = true;
            this.cmb_select.Location = new System.Drawing.Point(35, 224);
            this.cmb_select.Name = "cmb_select";
            this.cmb_select.Size = new System.Drawing.Size(246, 21);
            this.cmb_select.TabIndex = 24;
            this.cmb_select.ValueMember = "itemname";
            // 
            // itemBindingSource
            // 
            this.itemBindingSource.DataMember = "item";
            this.itemBindingSource.DataSource = this.adroit_lanka_dbDataSet1;
            // 
            // adroit_lanka_dbDataSet1
            // 
            this.adroit_lanka_dbDataSet1.DataSetName = "adroit_lanka_dbDataSet1";
            this.adroit_lanka_dbDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btn_search_cus_tele_num
            // 
            this.btn_search_cus_tele_num.Location = new System.Drawing.Point(507, 4);
            this.btn_search_cus_tele_num.Name = "btn_search_cus_tele_num";
            this.btn_search_cus_tele_num.Size = new System.Drawing.Size(107, 30);
            this.btn_search_cus_tele_num.TabIndex = 23;
            this.btn_search_cus_tele_num.Text = "Search";
            this.btn_search_cus_tele_num.UseVisualStyleBackColor = true;
            this.btn_search_cus_tele_num.Click += new System.EventHandler(this.btn_search_cus_tele_num_Click);
            // 
            // txt_enter_cus_tele_num
            // 
            this.txt_enter_cus_tele_num.Location = new System.Drawing.Point(204, 10);
            this.txt_enter_cus_tele_num.Name = "txt_enter_cus_tele_num";
            this.txt_enter_cus_tele_num.Size = new System.Drawing.Size(280, 20);
            this.txt_enter_cus_tele_num.TabIndex = 22;
            // 
            // lbl_enter_cus_tele_num
            // 
            this.lbl_enter_cus_tele_num.AutoSize = true;
            this.lbl_enter_cus_tele_num.Location = new System.Drawing.Point(32, 13);
            this.lbl_enter_cus_tele_num.Name = "lbl_enter_cus_tele_num";
            this.lbl_enter_cus_tele_num.Size = new System.Drawing.Size(153, 13);
            this.lbl_enter_cus_tele_num.TabIndex = 21;
            this.lbl_enter_cus_tele_num.Text = "Enter Customer Phone Number";
            // 
            // metro_panel_prepareshipment
            // 
            this.metro_panel_prepareshipment.BackColor = System.Drawing.Color.White;
            this.metro_panel_prepareshipment.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.metro_panel_prepareshipment.Controls.Add(this.button4);
            this.metro_panel_prepareshipment.Controls.Add(this.btn_cancel);
            this.metro_panel_prepareshipment.Controls.Add(this.btn_ok);
            this.metro_panel_prepareshipment.Controls.Add(this.DataGridPickingList);
            this.metro_panel_prepareshipment.Controls.Add(this.txt_cusadd);
            this.metro_panel_prepareshipment.Controls.Add(this.txt_cusname);
            this.metro_panel_prepareshipment.Controls.Add(this.txt_salesorderno);
            this.metro_panel_prepareshipment.Controls.Add(this.txt_pickinglistno);
            this.metro_panel_prepareshipment.Controls.Add(this.lbl_cusadd);
            this.metro_panel_prepareshipment.Controls.Add(this.lbl_cusname);
            this.metro_panel_prepareshipment.Controls.Add(this.lbl_salesorderno);
            this.metro_panel_prepareshipment.Controls.Add(this.lbl_pickinglistno);
            this.metro_panel_prepareshipment.HorizontalScrollbarBarColor = true;
            this.metro_panel_prepareshipment.HorizontalScrollbarHighlightOnWheel = false;
            this.metro_panel_prepareshipment.HorizontalScrollbarSize = 10;
            this.metro_panel_prepareshipment.Location = new System.Drawing.Point(0, 0);
            this.metro_panel_prepareshipment.Name = "metro_panel_prepareshipment";
            this.metro_panel_prepareshipment.Size = new System.Drawing.Size(1000, 441);
            this.metro_panel_prepareshipment.TabIndex = 8;
            this.metro_panel_prepareshipment.VerticalScrollbarBarColor = true;
            this.metro_panel_prepareshipment.VerticalScrollbarHighlightOnWheel = false;
            this.metro_panel_prepareshipment.VerticalScrollbarSize = 10;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(567, 105);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 30;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(446, 322);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 28;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(334, 322);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_ok.TabIndex = 29;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = true;
            // 
            // DataGridPickingList
            // 
            this.DataGridPickingList.AllowUserToOrderColumns = true;
            this.DataGridPickingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridPickingList.Location = new System.Drawing.Point(93, 194);
            this.DataGridPickingList.Name = "DataGridPickingList";
            this.DataGridPickingList.Size = new System.Drawing.Size(612, 101);
            this.DataGridPickingList.TabIndex = 27;
            // 
            // txt_cusadd
            // 
            this.txt_cusadd.Location = new System.Drawing.Point(230, 118);
            this.txt_cusadd.Multiline = true;
            this.txt_cusadd.Name = "txt_cusadd";
            this.txt_cusadd.Size = new System.Drawing.Size(117, 53);
            this.txt_cusadd.TabIndex = 25;
            // 
            // txt_cusname
            // 
            this.txt_cusname.Location = new System.Drawing.Point(231, 86);
            this.txt_cusname.Name = "txt_cusname";
            this.txt_cusname.Size = new System.Drawing.Size(116, 20);
            this.txt_cusname.TabIndex = 26;
            // 
            // txt_salesorderno
            // 
            this.txt_salesorderno.Location = new System.Drawing.Point(446, 48);
            this.txt_salesorderno.Name = "txt_salesorderno";
            this.txt_salesorderno.Size = new System.Drawing.Size(117, 20);
            this.txt_salesorderno.TabIndex = 23;
            // 
            // txt_pickinglistno
            // 
            this.txt_pickinglistno.Location = new System.Drawing.Point(214, 51);
            this.txt_pickinglistno.Name = "txt_pickinglistno";
            this.txt_pickinglistno.Size = new System.Drawing.Size(117, 20);
            this.txt_pickinglistno.TabIndex = 24;
            // 
            // lbl_cusadd
            // 
            this.lbl_cusadd.AutoSize = true;
            this.lbl_cusadd.Location = new System.Drawing.Point(129, 125);
            this.lbl_cusadd.Name = "lbl_cusadd";
            this.lbl_cusadd.Size = new System.Drawing.Size(95, 13);
            this.lbl_cusadd.TabIndex = 21;
            this.lbl_cusadd.Text = "Customer Address:";
            // 
            // lbl_cusname
            // 
            this.lbl_cusname.AutoSize = true;
            this.lbl_cusname.Location = new System.Drawing.Point(129, 86);
            this.lbl_cusname.Name = "lbl_cusname";
            this.lbl_cusname.Size = new System.Drawing.Size(85, 13);
            this.lbl_cusname.TabIndex = 22;
            this.lbl_cusname.Text = "Customer Name:";
            // 
            // lbl_salesorderno
            // 
            this.lbl_salesorderno.AutoSize = true;
            this.lbl_salesorderno.Location = new System.Drawing.Point(360, 51);
            this.lbl_salesorderno.Name = "lbl_salesorderno";
            this.lbl_salesorderno.Size = new System.Drawing.Size(80, 13);
            this.lbl_salesorderno.TabIndex = 20;
            this.lbl_salesorderno.Text = "Sales Order no:";
            // 
            // lbl_pickinglistno
            // 
            this.lbl_pickinglistno.AutoSize = true;
            this.lbl_pickinglistno.Location = new System.Drawing.Point(129, 51);
            this.lbl_pickinglistno.Name = "lbl_pickinglistno";
            this.lbl_pickinglistno.Size = new System.Drawing.Size(79, 13);
            this.lbl_pickinglistno.TabIndex = 19;
            this.lbl_pickinglistno.Text = "Picking List no:";
            // 
            // tl_btn_placeorder
            // 
            this.tl_btn_placeorder.ActiveControl = null;
            this.tl_btn_placeorder.Location = new System.Drawing.Point(20, 88);
            this.tl_btn_placeorder.Name = "tl_btn_placeorder";
            this.tl_btn_placeorder.Size = new System.Drawing.Size(159, 61);
            this.tl_btn_placeorder.TabIndex = 9;
            this.tl_btn_placeorder.Text = "Place \r\norder";
            this.tl_btn_placeorder.UseSelectable = true;
            this.tl_btn_placeorder.Click += new System.EventHandler(this.tl_btn_placeorder_Click_1);
            // 
            // metro_panel_recordstock
            // 
            this.metro_panel_recordstock.Controls.Add(this.metro_panel_prepareshipment);
            this.metro_panel_recordstock.Controls.Add(this.metroTile6);
            this.metro_panel_recordstock.Controls.Add(this.comboBox1);
            this.metro_panel_recordstock.Controls.Add(this.txt_chkby);
            this.metro_panel_recordstock.Controls.Add(this.lbl_chkby);
            this.metro_panel_recordstock.Controls.Add(this.txt_pkdby);
            this.metro_panel_recordstock.Controls.Add(this.lbl_pkdby);
            this.metro_panel_recordstock.Controls.Add(this.lbl_pklnum);
            this.metro_panel_recordstock.HorizontalScrollbarBarColor = true;
            this.metro_panel_recordstock.HorizontalScrollbarHighlightOnWheel = false;
            this.metro_panel_recordstock.HorizontalScrollbarSize = 10;
            this.metro_panel_recordstock.Location = new System.Drawing.Point(23, 159);
            this.metro_panel_recordstock.Name = "metro_panel_recordstock";
            this.metro_panel_recordstock.Size = new System.Drawing.Size(940, 498);
            this.metro_panel_recordstock.TabIndex = 10;
            this.metro_panel_recordstock.VerticalScrollbarBarColor = true;
            this.metro_panel_recordstock.VerticalScrollbarHighlightOnWheel = false;
            this.metro_panel_recordstock.VerticalScrollbarSize = 10;
            // 
            // metroTile6
            // 
            this.metroTile6.ActiveControl = null;
            this.metroTile6.Location = new System.Drawing.Point(69, 350);
            this.metroTile6.Name = "metroTile6";
            this.metroTile6.Size = new System.Drawing.Size(78, 39);
            this.metroTile6.TabIndex = 10;
            this.metroTile6.Text = "Update";
            this.metroTile6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.metroTile6.UseSelectable = true;
            this.metroTile6.Click += new System.EventHandler(this.metroTile6_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.pickinglistdetailBindingSource;
            this.comboBox1.DisplayMember = "pickinglistno";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(206, 99);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 9;
            // 
            // pickinglistdetailBindingSource
            // 
            this.pickinglistdetailBindingSource.DataMember = "pickinglistdetail";
            this.pickinglistdetailBindingSource.DataSource = this.adroit_lanka_dbDataSet;
            // 
            // adroit_lanka_dbDataSet
            // 
            this.adroit_lanka_dbDataSet.DataSetName = "adroit_lanka_dbDataSet";
            this.adroit_lanka_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txt_chkby
            // 
            this.txt_chkby.Location = new System.Drawing.Point(206, 212);
            this.txt_chkby.Name = "txt_chkby";
            this.txt_chkby.Size = new System.Drawing.Size(100, 20);
            this.txt_chkby.TabIndex = 8;
            // 
            // lbl_chkby
            // 
            this.lbl_chkby.AutoSize = true;
            this.lbl_chkby.Location = new System.Drawing.Point(66, 215);
            this.lbl_chkby.Name = "lbl_chkby";
            this.lbl_chkby.Size = new System.Drawing.Size(65, 13);
            this.lbl_chkby.TabIndex = 7;
            this.lbl_chkby.Text = "Checked By";
            // 
            // txt_pkdby
            // 
            this.txt_pkdby.Location = new System.Drawing.Point(206, 153);
            this.txt_pkdby.Name = "txt_pkdby";
            this.txt_pkdby.Size = new System.Drawing.Size(100, 20);
            this.txt_pkdby.TabIndex = 6;
            // 
            // lbl_pkdby
            // 
            this.lbl_pkdby.AutoSize = true;
            this.lbl_pkdby.Location = new System.Drawing.Point(66, 159);
            this.lbl_pkdby.Name = "lbl_pkdby";
            this.lbl_pkdby.Size = new System.Drawing.Size(59, 13);
            this.lbl_pkdby.TabIndex = 5;
            this.lbl_pkdby.Text = "Packed By";
            // 
            // lbl_pklnum
            // 
            this.lbl_pklnum.AutoSize = true;
            this.lbl_pklnum.Location = new System.Drawing.Point(66, 102);
            this.lbl_pklnum.Name = "lbl_pklnum";
            this.lbl_pklnum.Size = new System.Drawing.Size(101, 13);
            this.lbl_pklnum.TabIndex = 3;
            this.lbl_pklnum.Text = "Picking List Number";
            // 
            // metro_panel_printinvoices
            // 
            this.metro_panel_printinvoices.Controls.Add(this.metroTile5);
            this.metro_panel_printinvoices.Controls.Add(this.button2);
            this.metro_panel_printinvoices.HorizontalScrollbarBarColor = true;
            this.metro_panel_printinvoices.HorizontalScrollbarHighlightOnWheel = false;
            this.metro_panel_printinvoices.HorizontalScrollbarSize = 10;
            this.metro_panel_printinvoices.Location = new System.Drawing.Point(23, 159);
            this.metro_panel_printinvoices.Name = "metro_panel_printinvoices";
            this.metro_panel_printinvoices.Size = new System.Drawing.Size(940, 498);
            this.metro_panel_printinvoices.TabIndex = 11;
            this.metro_panel_printinvoices.VerticalScrollbarBarColor = true;
            this.metro_panel_printinvoices.VerticalScrollbarHighlightOnWheel = false;
            this.metro_panel_printinvoices.VerticalScrollbarSize = 10;
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Location = new System.Drawing.Point(418, 8);
            this.metroTile5.Name = "metroTile5";
            this.metroTile5.Size = new System.Drawing.Size(395, 377);
            this.metroTile5.Style = MetroFramework.MetroColorStyle.Silver;
            this.metroTile5.TabIndex = 4;
            this.metroTile5.Text = "Delivery Notes";
            this.metroTile5.UseSelectable = true;
            this.metroTile5.Click += new System.EventHandler(this.metroTile5_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(21, 34);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(129, 28);
            this.button2.TabIndex = 2;
            this.button2.Text = "screen4";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // metro_panel_updatestock
            // 
            this.metro_panel_updatestock.Controls.Add(this.button3);
            this.metro_panel_updatestock.HorizontalScrollbarBarColor = true;
            this.metro_panel_updatestock.HorizontalScrollbarHighlightOnWheel = false;
            this.metro_panel_updatestock.HorizontalScrollbarSize = 10;
            this.metro_panel_updatestock.Location = new System.Drawing.Point(201, 185);
            this.metro_panel_updatestock.Name = "metro_panel_updatestock";
            this.metro_panel_updatestock.Size = new System.Drawing.Size(256, 156);
            this.metro_panel_updatestock.TabIndex = 12;
            this.metro_panel_updatestock.VerticalScrollbarBarColor = true;
            this.metro_panel_updatestock.VerticalScrollbarHighlightOnWheel = false;
            this.metro_panel_updatestock.VerticalScrollbarSize = 10;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(111, 190);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(188, 47);
            this.button3.TabIndex = 2;
            this.button3.Text = "screen5";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // mt_btn_updtstock
            // 
            this.mt_btn_updtstock.ActiveControl = null;
            this.mt_btn_updtstock.Location = new System.Drawing.Point(636, 88);
            this.mt_btn_updtstock.Name = "mt_btn_updtstock";
            this.mt_btn_updtstock.Size = new System.Drawing.Size(126, 61);
            this.mt_btn_updtstock.TabIndex = 13;
            this.mt_btn_updtstock.Text = "Update \r\nStock";
            this.mt_btn_updtstock.UseSelectable = true;
            this.mt_btn_updtstock.Click += new System.EventHandler(this.mt_btn_updtstock_Click);
            // 
            // pickinglistdetailTableAdapter
            // 
            this.pickinglistdetailTableAdapter.ClearBeforeFill = true;
            // 
            // itemTableAdapter
            // 
            this.itemTableAdapter.ClearBeforeFill = true;
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(973, 680);
            this.Controls.Add(this.mt_btn_updtstock);
            this.Controls.Add(this.tl_btn_placeorder);
            this.Controls.Add(this.metro_panel_placeorder);
            this.Controls.Add(this.metroTile3);
            this.Controls.Add(this.metroTile2);
            this.Controls.Add(this.metroTile1);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.metro_panel_updatestock);
            this.Controls.Add(this.metro_panel_recordstock);
            this.Controls.Add(this.metro_panel_printinvoices);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainMenu";
            this.Text = "ADROIT Lanka - Order Processing System";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.metro_panel_placeorder.ResumeLayout(false);
            this.metro_panel_placeorder.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_qty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid_cus_detail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adroit_lanka_dbDataSet1)).EndInit();
            this.metro_panel_prepareshipment.ResumeLayout(false);
            this.metro_panel_prepareshipment.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPickingList)).EndInit();
            this.metro_panel_recordstock.ResumeLayout(false);
            this.metro_panel_recordstock.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pickinglistdetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.adroit_lanka_dbDataSet)).EndInit();
            this.metro_panel_printinvoices.ResumeLayout(false);
            this.metro_panel_updatestock.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tasksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroTile metroTile2;
        private MetroFramework.Controls.MetroTile metroTile3;
        private MetroFramework.Controls.MetroPanel metro_panel_placeorder;
        private MetroFramework.Controls.MetroPanel metro_panel_prepareshipment;
        private MetroFramework.Controls.MetroTile tl_btn_placeorder;
        private MetroFramework.Controls.MetroPanel metro_panel_recordstock;
        private MetroFramework.Controls.MetroPanel metro_panel_printinvoices;
        private System.Windows.Forms.Button button2;
        private MetroFramework.Controls.MetroPanel metro_panel_updatestock;
        private System.Windows.Forms.Button button3;
        private MetroFramework.Controls.MetroTile mt_btn_updtstock;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.DataGridView DataGridPickingList;
        private System.Windows.Forms.TextBox txt_cusadd;
        private System.Windows.Forms.TextBox txt_cusname;
        private System.Windows.Forms.TextBox txt_salesorderno;
        private System.Windows.Forms.TextBox txt_pickinglistno;
        private System.Windows.Forms.Label lbl_cusadd;
        private System.Windows.Forms.Label lbl_cusname;
        private System.Windows.Forms.Label lbl_salesorderno;
        private System.Windows.Forms.Label lbl_pickinglistno;
        private MetroFramework.Controls.MetroTile metroTile5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox txt_chkby;
        private System.Windows.Forms.Label lbl_chkby;
        private System.Windows.Forms.TextBox txt_pkdby;
        private System.Windows.Forms.Label lbl_pkdby;
        private System.Windows.Forms.Label lbl_pklnum;
        private adroit_lanka_dbDataSet adroit_lanka_dbDataSet;
        private System.Windows.Forms.BindingSource pickinglistdetailBindingSource;
        private adroit_lanka_dbDataSetTableAdapters.pickinglistdetailTableAdapter pickinglistdetailTableAdapter;
        private MetroFramework.Controls.MetroTile metroTile6;
        private System.Windows.Forms.Button btn_addcus;
        private System.Windows.Forms.Button btn_place;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbl_itemno;
        private System.Windows.Forms.TextBox txt_itemno;
        private System.Windows.Forms.DataGridView dataGrid_cus_detail;
        private System.Windows.Forms.Button btn_add_qty;
        private System.Windows.Forms.TextBox txt_qty;
        private System.Windows.Forms.Label lbl_qty;
        private System.Windows.Forms.Label lbi_select_items;
        private System.Windows.Forms.ComboBox cmb_select;
        private System.Windows.Forms.Button btn_search_cus_tele_num;
        private System.Windows.Forms.TextBox txt_enter_cus_tele_num;
        private System.Windows.Forms.Label lbl_enter_cus_tele_num;
        private adroit_lanka_dbDataSet1 adroit_lanka_dbDataSet1;
        private System.Windows.Forms.BindingSource itemBindingSource;
        private adroit_lanka_dbDataSet1TableAdapters.itemTableAdapter itemTableAdapter;
        private System.Windows.Forms.DataGridView dataGrid_qty;
        private MetroFramework.Controls.MetroTile metroTile4;
    }
}