﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsMain
{
    public partial class FormbfGPL : MetroFramework.Forms.MetroForm
    {
        public FormbfGPL()
        {
            InitializeComponent();
        }

        private void FormbfGPL_Load(object sender, EventArgs e)
        {

        }
        private void metroButton1_Click(object sender, EventArgs e)
        {
            GeneratePickingList gpl1 = new GeneratePickingList();
            gpl1.SetSalesOrderNo(txt_salesorderno.Text);
            gpl1.Show();
        }
    }
}
