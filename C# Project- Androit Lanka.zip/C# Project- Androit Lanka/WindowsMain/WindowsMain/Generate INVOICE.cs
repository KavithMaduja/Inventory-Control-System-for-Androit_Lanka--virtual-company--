﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsMain
{
    public partial class Generate_INVOICE : MetroFramework.Forms.MetroForm
    {
        public Generate_INVOICE()
        {
            InitializeComponent();
        }

        private void Generate_INVOICE_Load(object sender, EventArgs e)
        {

        }
    }
}
