﻿namespace WindowsMain
{
    partial class Generate_INVOICE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_total = new System.Windows.Forms.Label();
            this.label_total = new System.Windows.Forms.Label();
            this.lbl_no_of_items = new System.Windows.Forms.Label();
            this.label_noofitems = new System.Windows.Forms.Label();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_search = new System.Windows.Forms.Button();
            this.txt_sales_order_no = new System.Windows.Forms.TextBox();
            this.lbl_salesorderno = new System.Windows.Forms.Label();
            this.lbl_pageno = new System.Windows.Forms.Label();
            this.lbl_terms = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_invoice_no = new System.Windows.Forms.Label();
            this.label_pageno = new System.Windows.Forms.Label();
            this.label_terms = new System.Windows.Forms.Label();
            this.label_date = new System.Windows.Forms.Label();
            this.lbl_inNO = new System.Windows.Forms.Label();
            this.lbl_cmpname = new System.Windows.Forms.Label();
            this.lbl_cusname = new System.Windows.Forms.Label();
            this.lable = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_company = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_total
            // 
            this.lbl_total.AutoSize = true;
            this.lbl_total.Location = new System.Drawing.Point(472, 385);
            this.lbl_total.Name = "lbl_total";
            this.lbl_total.Size = new System.Drawing.Size(41, 13);
            this.lbl_total.TabIndex = 57;
            this.lbl_total.Text = "label23";
            this.lbl_total.Visible = false;
            // 
            // label_total
            // 
            this.label_total.AutoSize = true;
            this.label_total.Location = new System.Drawing.Point(363, 385);
            this.label_total.Name = "label_total";
            this.label_total.Size = new System.Drawing.Size(31, 13);
            this.label_total.TabIndex = 56;
            this.label_total.Text = "Total";
            // 
            // lbl_no_of_items
            // 
            this.lbl_no_of_items.AutoSize = true;
            this.lbl_no_of_items.Location = new System.Drawing.Point(472, 360);
            this.lbl_no_of_items.Name = "lbl_no_of_items";
            this.lbl_no_of_items.Size = new System.Drawing.Size(41, 13);
            this.lbl_no_of_items.TabIndex = 55;
            this.lbl_no_of_items.Text = "label17";
            this.lbl_no_of_items.Visible = false;
            // 
            // label_noofitems
            // 
            this.label_noofitems.AutoSize = true;
            this.label_noofitems.Location = new System.Drawing.Point(363, 360);
            this.label_noofitems.Name = "label_noofitems";
            this.label_noofitems.Size = new System.Drawing.Size(61, 13);
            this.label_noofitems.TabIndex = 54;
            this.label_noofitems.Text = "No of Items";
            // 
            // btn_exit
            // 
            this.btn_exit.Location = new System.Drawing.Point(147, 415);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(58, 28);
            this.btn_exit.TabIndex = 53;
            this.btn_exit.Text = "Exit";
            this.btn_exit.UseVisualStyleBackColor = true;
            // 
            // btn_clear
            // 
            this.btn_clear.Location = new System.Drawing.Point(83, 415);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(58, 28);
            this.btn_clear.TabIndex = 52;
            this.btn_clear.Text = "Clear";
            this.btn_clear.UseVisualStyleBackColor = true;
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(19, 415);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(58, 28);
            this.btn_ok.TabIndex = 51;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(19, 187);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(540, 170);
            this.dataGridView1.TabIndex = 50;
            // 
            // btn_search
            // 
            this.btn_search.Location = new System.Drawing.Point(220, 161);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(52, 20);
            this.btn_search.TabIndex = 49;
            this.btn_search.Text = "Search";
            this.btn_search.UseVisualStyleBackColor = true;
            // 
            // txt_sales_order_no
            // 
            this.txt_sales_order_no.Location = new System.Drawing.Point(103, 161);
            this.txt_sales_order_no.Name = "txt_sales_order_no";
            this.txt_sales_order_no.Size = new System.Drawing.Size(111, 20);
            this.txt_sales_order_no.TabIndex = 48;
            // 
            // lbl_salesorderno
            // 
            this.lbl_salesorderno.AutoSize = true;
            this.lbl_salesorderno.Location = new System.Drawing.Point(16, 164);
            this.lbl_salesorderno.Name = "lbl_salesorderno";
            this.lbl_salesorderno.Size = new System.Drawing.Size(81, 13);
            this.lbl_salesorderno.TabIndex = 47;
            this.lbl_salesorderno.Text = "Sales Order NO";
            // 
            // lbl_pageno
            // 
            this.lbl_pageno.AutoSize = true;
            this.lbl_pageno.Location = new System.Drawing.Point(518, 164);
            this.lbl_pageno.Name = "lbl_pageno";
            this.lbl_pageno.Size = new System.Drawing.Size(41, 13);
            this.lbl_pageno.TabIndex = 46;
            this.lbl_pageno.Text = "label14";
            this.lbl_pageno.Visible = false;
            // 
            // lbl_terms
            // 
            this.lbl_terms.AutoSize = true;
            this.lbl_terms.Location = new System.Drawing.Point(518, 142);
            this.lbl_terms.Name = "lbl_terms";
            this.lbl_terms.Size = new System.Drawing.Size(41, 13);
            this.lbl_terms.TabIndex = 45;
            this.lbl_terms.Text = "label13";
            this.lbl_terms.Visible = false;
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Location = new System.Drawing.Point(518, 118);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(41, 13);
            this.lbl_date.TabIndex = 44;
            this.lbl_date.Text = "label12";
            this.lbl_date.Visible = false;
            // 
            // lbl_invoice_no
            // 
            this.lbl_invoice_no.AutoSize = true;
            this.lbl_invoice_no.Location = new System.Drawing.Point(518, 95);
            this.lbl_invoice_no.Name = "lbl_invoice_no";
            this.lbl_invoice_no.Size = new System.Drawing.Size(41, 13);
            this.lbl_invoice_no.TabIndex = 43;
            this.lbl_invoice_no.Text = "label11";
            this.lbl_invoice_no.Visible = false;
            // 
            // label_pageno
            // 
            this.label_pageno.AutoSize = true;
            this.label_pageno.Location = new System.Drawing.Point(431, 164);
            this.label_pageno.Name = "label_pageno";
            this.label_pageno.Size = new System.Drawing.Size(51, 13);
            this.label_pageno.TabIndex = 42;
            this.label_pageno.Text = "Page NO";
            // 
            // label_terms
            // 
            this.label_terms.AutoSize = true;
            this.label_terms.Location = new System.Drawing.Point(431, 142);
            this.label_terms.Name = "label_terms";
            this.label_terms.Size = new System.Drawing.Size(36, 13);
            this.label_terms.TabIndex = 41;
            this.label_terms.Text = "Terms";
            // 
            // label_date
            // 
            this.label_date.AutoSize = true;
            this.label_date.Location = new System.Drawing.Point(431, 118);
            this.label_date.Name = "label_date";
            this.label_date.Size = new System.Drawing.Size(30, 13);
            this.label_date.TabIndex = 40;
            this.label_date.Text = "Date";
            // 
            // lbl_inNO
            // 
            this.lbl_inNO.AutoSize = true;
            this.lbl_inNO.Location = new System.Drawing.Point(431, 95);
            this.lbl_inNO.Name = "lbl_inNO";
            this.lbl_inNO.Size = new System.Drawing.Size(61, 13);
            this.lbl_inNO.TabIndex = 39;
            this.lbl_inNO.Text = "Invoice NO";
            // 
            // lbl_cmpname
            // 
            this.lbl_cmpname.AutoSize = true;
            this.lbl_cmpname.Location = new System.Drawing.Point(71, 95);
            this.lbl_cmpname.Name = "lbl_cmpname";
            this.lbl_cmpname.Size = new System.Drawing.Size(35, 13);
            this.lbl_cmpname.TabIndex = 38;
            this.lbl_cmpname.Text = "label6";
            this.lbl_cmpname.Visible = false;
            // 
            // lbl_cusname
            // 
            this.lbl_cusname.AutoSize = true;
            this.lbl_cusname.Location = new System.Drawing.Point(71, 118);
            this.lbl_cusname.Name = "lbl_cusname";
            this.lbl_cusname.Size = new System.Drawing.Size(35, 13);
            this.lbl_cusname.TabIndex = 37;
            this.lbl_cusname.Text = "label5";
            this.lbl_cusname.Visible = false;
            // 
            // lable
            // 
            this.lable.AutoSize = true;
            this.lable.Location = new System.Drawing.Point(16, 95);
            this.lable.Name = "lable";
            this.lable.Size = new System.Drawing.Size(49, 13);
            this.lable.TabIndex = 36;
            this.lable.Text = "Sold to : ";
            // 
            // label4
            // 
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Location = new System.Drawing.Point(20, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(670, 20);
            this.label4.TabIndex = 35;
            this.label4.Text = "adroit.lanka@gmail.com";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.Location = new System.Drawing.Point(20, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(670, 22);
            this.label3.TabIndex = 34;
            this.label3.Text = "0754287749";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Location = new System.Drawing.Point(20, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(670, 22);
            this.label2.TabIndex = 33;
            this.label2.Text = "colombo 7";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(20, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(670, 22);
            this.label1.TabIndex = 32;
            this.label1.Text = "Adroit Lanka Pvt.Ltd";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_company
            // 
            this.lbl_company.AutoSize = true;
            this.lbl_company.Location = new System.Drawing.Point(295, 0);
            this.lbl_company.Name = "lbl_company";
            this.lbl_company.Size = new System.Drawing.Size(0, 13);
            this.lbl_company.TabIndex = 31;
            // 
            // Generate_INVOICE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(710, 469);
            this.Controls.Add(this.lbl_total);
            this.Controls.Add(this.label_total);
            this.Controls.Add(this.lbl_no_of_items);
            this.Controls.Add(this.label_noofitems);
            this.Controls.Add(this.btn_exit);
            this.Controls.Add(this.btn_clear);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.txt_sales_order_no);
            this.Controls.Add(this.lbl_salesorderno);
            this.Controls.Add(this.lbl_pageno);
            this.Controls.Add(this.lbl_terms);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.lbl_invoice_no);
            this.Controls.Add(this.label_pageno);
            this.Controls.Add(this.label_terms);
            this.Controls.Add(this.label_date);
            this.Controls.Add(this.lbl_inNO);
            this.Controls.Add(this.lbl_cmpname);
            this.Controls.Add(this.lbl_cusname);
            this.Controls.Add(this.lable);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_company);
            this.Name = "Generate_INVOICE";
            this.Text = "Generate_INVOICE";
            this.Load += new System.EventHandler(this.Generate_INVOICE_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_total;
        private System.Windows.Forms.Label label_total;
        private System.Windows.Forms.Label lbl_no_of_items;
        private System.Windows.Forms.Label label_noofitems;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox txt_sales_order_no;
        private System.Windows.Forms.Label lbl_salesorderno;
        private System.Windows.Forms.Label lbl_pageno;
        private System.Windows.Forms.Label lbl_terms;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_invoice_no;
        private System.Windows.Forms.Label label_pageno;
        private System.Windows.Forms.Label label_terms;
        private System.Windows.Forms.Label label_date;
        private System.Windows.Forms.Label lbl_inNO;
        private System.Windows.Forms.Label lbl_cmpname;
        private System.Windows.Forms.Label lbl_cusname;
        private System.Windows.Forms.Label lable;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_company;
    }
}