﻿namespace WindowsMain
{
    partial class DeliveryNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txt_AddL2 = new System.Windows.Forms.TextBox();
            this.txt_AdL3 = new System.Windows.Forms.TextBox();
            this.lbl_AddL2 = new System.Windows.Forms.Label();
            this.lbl_AddL3 = new System.Windows.Forms.Label();
            this.txt_ConLName = new System.Windows.Forms.TextBox();
            this.txt_ConFName = new System.Windows.Forms.TextBox();
            this.lbl_ConFName = new System.Windows.Forms.Label();
            this.lbl_ConLName = new System.Windows.Forms.Label();
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.txt_InvNo = new System.Windows.Forms.TextBox();
            this.lbl_InvNo = new System.Windows.Forms.Label();
            this.txt_Date = new System.Windows.Forms.TextBox();
            this.txt_AddL1 = new System.Windows.Forms.TextBox();
            this.txt_CusName = new System.Windows.Forms.TextBox();
            this.txt_DNo = new System.Windows.Forms.TextBox();
            this.lbl_Date = new System.Windows.Forms.Label();
            this.lbl_AddL1 = new System.Windows.Forms.Label();
            this.lbl_CusName = new System.Windows.Forms.Label();
            this.lbl_DNo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(62, 349);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(580, 97);
            this.dataGridView1.TabIndex = 48;
            // 
            // txt_AddL2
            // 
            this.txt_AddL2.Location = new System.Drawing.Point(246, 235);
            this.txt_AddL2.Name = "txt_AddL2";
            this.txt_AddL2.Size = new System.Drawing.Size(171, 20);
            this.txt_AddL2.TabIndex = 47;
            // 
            // txt_AdL3
            // 
            this.txt_AdL3.Location = new System.Drawing.Point(246, 263);
            this.txt_AdL3.Name = "txt_AdL3";
            this.txt_AdL3.Size = new System.Drawing.Size(171, 20);
            this.txt_AdL3.TabIndex = 46;
            // 
            // lbl_AddL2
            // 
            this.lbl_AddL2.AutoSize = true;
            this.lbl_AddL2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AddL2.Location = new System.Drawing.Point(75, 239);
            this.lbl_AddL2.Name = "lbl_AddL2";
            this.lbl_AddL2.Size = new System.Drawing.Size(97, 16);
            this.lbl_AddL2.TabIndex = 45;
            this.lbl_AddL2.Text = "Address Line 2";
            // 
            // lbl_AddL3
            // 
            this.lbl_AddL3.AutoSize = true;
            this.lbl_AddL3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AddL3.Location = new System.Drawing.Point(76, 267);
            this.lbl_AddL3.Name = "lbl_AddL3";
            this.lbl_AddL3.Size = new System.Drawing.Size(97, 16);
            this.lbl_AddL3.TabIndex = 44;
            this.lbl_AddL3.Text = "Address Line 3";
            // 
            // txt_ConLName
            // 
            this.txt_ConLName.Location = new System.Drawing.Point(246, 172);
            this.txt_ConLName.Name = "txt_ConLName";
            this.txt_ConLName.Size = new System.Drawing.Size(171, 20);
            this.txt_ConLName.TabIndex = 43;
            // 
            // txt_ConFName
            // 
            this.txt_ConFName.Location = new System.Drawing.Point(246, 138);
            this.txt_ConFName.Name = "txt_ConFName";
            this.txt_ConFName.Size = new System.Drawing.Size(171, 20);
            this.txt_ConFName.TabIndex = 42;
            // 
            // lbl_ConFName
            // 
            this.lbl_ConFName.AutoSize = true;
            this.lbl_ConFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ConFName.Location = new System.Drawing.Point(75, 138);
            this.lbl_ConFName.Name = "lbl_ConFName";
            this.lbl_ConFName.Size = new System.Drawing.Size(101, 16);
            this.lbl_ConFName.TabIndex = 41;
            this.lbl_ConFName.Text = "Contact FName";
            // 
            // lbl_ConLName
            // 
            this.lbl_ConLName.AutoSize = true;
            this.lbl_ConLName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ConLName.Location = new System.Drawing.Point(75, 172);
            this.lbl_ConLName.Name = "lbl_ConLName";
            this.lbl_ConLName.Size = new System.Drawing.Size(103, 16);
            this.lbl_ConLName.TabIndex = 40;
            this.lbl_ConLName.Text = "Contact LName.";
            // 
            // btn_cancel
            // 
            this.btn_cancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancel.Location = new System.Drawing.Point(460, 478);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(82, 25);
            this.btn_cancel.TabIndex = 39;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            // 
            // btn_OK
            // 
            this.btn_OK.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_OK.Location = new System.Drawing.Point(341, 475);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(82, 25);
            this.btn_OK.TabIndex = 38;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.btn_OK_Click);
            // 
            // txt_InvNo
            // 
            this.txt_InvNo.Location = new System.Drawing.Point(450, 306);
            this.txt_InvNo.Name = "txt_InvNo";
            this.txt_InvNo.Size = new System.Drawing.Size(144, 20);
            this.txt_InvNo.TabIndex = 37;
            // 
            // lbl_InvNo
            // 
            this.lbl_InvNo.AutoSize = true;
            this.lbl_InvNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_InvNo.Location = new System.Drawing.Point(351, 310);
            this.lbl_InvNo.Name = "lbl_InvNo";
            this.lbl_InvNo.Size = new System.Drawing.Size(72, 16);
            this.lbl_InvNo.TabIndex = 36;
            this.lbl_InvNo.Text = "Invoice No";
            // 
            // txt_Date
            // 
            this.txt_Date.Location = new System.Drawing.Point(169, 310);
            this.txt_Date.Name = "txt_Date";
            this.txt_Date.Size = new System.Drawing.Size(176, 20);
            this.txt_Date.TabIndex = 35;
            // 
            // txt_AddL1
            // 
            this.txt_AddL1.Location = new System.Drawing.Point(246, 203);
            this.txt_AddL1.Name = "txt_AddL1";
            this.txt_AddL1.Size = new System.Drawing.Size(171, 20);
            this.txt_AddL1.TabIndex = 34;
            // 
            // txt_CusName
            // 
            this.txt_CusName.Location = new System.Drawing.Point(246, 102);
            this.txt_CusName.Name = "txt_CusName";
            this.txt_CusName.Size = new System.Drawing.Size(171, 20);
            this.txt_CusName.TabIndex = 33;
            // 
            // txt_DNo
            // 
            this.txt_DNo.Location = new System.Drawing.Point(246, 63);
            this.txt_DNo.Name = "txt_DNo";
            this.txt_DNo.Size = new System.Drawing.Size(171, 20);
            this.txt_DNo.TabIndex = 32;
            // 
            // lbl_Date
            // 
            this.lbl_Date.AutoSize = true;
            this.lbl_Date.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Date.Location = new System.Drawing.Point(75, 314);
            this.lbl_Date.Name = "lbl_Date";
            this.lbl_Date.Size = new System.Drawing.Size(37, 16);
            this.lbl_Date.TabIndex = 31;
            this.lbl_Date.Text = "Date";
            // 
            // lbl_AddL1
            // 
            this.lbl_AddL1.AutoSize = true;
            this.lbl_AddL1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AddL1.Location = new System.Drawing.Point(75, 207);
            this.lbl_AddL1.Name = "lbl_AddL1";
            this.lbl_AddL1.Size = new System.Drawing.Size(97, 16);
            this.lbl_AddL1.TabIndex = 30;
            this.lbl_AddL1.Text = "Address Line 1";
            // 
            // lbl_CusName
            // 
            this.lbl_CusName.AutoSize = true;
            this.lbl_CusName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_CusName.Location = new System.Drawing.Point(75, 102);
            this.lbl_CusName.Name = "lbl_CusName";
            this.lbl_CusName.Size = new System.Drawing.Size(105, 16);
            this.lbl_CusName.TabIndex = 29;
            this.lbl_CusName.Text = "Customer Name";
            // 
            // lbl_DNo
            // 
            this.lbl_DNo.AutoSize = true;
            this.lbl_DNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DNo.Location = new System.Drawing.Point(75, 64);
            this.lbl_DNo.Name = "lbl_DNo";
            this.lbl_DNo.Size = new System.Drawing.Size(111, 16);
            this.lbl_DNo.TabIndex = 28;
            this.lbl_DNo.Text = "Delivery Note No";
            // 
            // DeliveryNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(817, 571);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txt_AddL2);
            this.Controls.Add(this.txt_AdL3);
            this.Controls.Add(this.lbl_AddL2);
            this.Controls.Add(this.lbl_AddL3);
            this.Controls.Add(this.txt_ConLName);
            this.Controls.Add(this.txt_ConFName);
            this.Controls.Add(this.lbl_ConFName);
            this.Controls.Add(this.lbl_ConLName);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.txt_InvNo);
            this.Controls.Add(this.lbl_InvNo);
            this.Controls.Add(this.txt_Date);
            this.Controls.Add(this.txt_AddL1);
            this.Controls.Add(this.txt_CusName);
            this.Controls.Add(this.txt_DNo);
            this.Controls.Add(this.lbl_Date);
            this.Controls.Add(this.lbl_AddL1);
            this.Controls.Add(this.lbl_CusName);
            this.Controls.Add(this.lbl_DNo);
            this.Name = "DeliveryNote";
            this.Text = "Print Delivery note";
            this.Load += new System.EventHandler(this.DeliveryNote_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txt_AddL2;
        private System.Windows.Forms.TextBox txt_AdL3;
        private System.Windows.Forms.Label lbl_AddL2;
        private System.Windows.Forms.Label lbl_AddL3;
        private System.Windows.Forms.TextBox txt_ConLName;
        private System.Windows.Forms.TextBox txt_ConFName;
        private System.Windows.Forms.Label lbl_ConFName;
        private System.Windows.Forms.Label lbl_ConLName;
        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.TextBox txt_InvNo;
        private System.Windows.Forms.Label lbl_InvNo;
        private System.Windows.Forms.TextBox txt_Date;
        private System.Windows.Forms.TextBox txt_AddL1;
        private System.Windows.Forms.TextBox txt_CusName;
        private System.Windows.Forms.TextBox txt_DNo;
        private System.Windows.Forms.Label lbl_Date;
        private System.Windows.Forms.Label lbl_AddL1;
        private System.Windows.Forms.Label lbl_CusName;
        private System.Windows.Forms.Label lbl_DNo;
    }
}