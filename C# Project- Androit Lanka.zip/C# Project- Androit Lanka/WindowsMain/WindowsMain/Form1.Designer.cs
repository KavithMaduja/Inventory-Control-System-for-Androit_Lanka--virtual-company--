﻿namespace WindowsMain
{
    partial class GeneratePickingList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_cancel = new System.Windows.Forms.Button();
            this.btn_ok = new System.Windows.Forms.Button();
            this.DataGridPickingList = new System.Windows.Forms.DataGridView();
            this.txt_cusadd = new System.Windows.Forms.TextBox();
            this.txt_cusname = new System.Windows.Forms.TextBox();
            this.txt_salesorderno = new System.Windows.Forms.TextBox();
            this.txt_pickinglistno = new System.Windows.Forms.TextBox();
            this.lbl_cusadd = new System.Windows.Forms.Label();
            this.lbl_cusname = new System.Windows.Forms.Label();
            this.lbl_salesorderno = new System.Windows.Forms.Label();
            this.lbl_pickinglistno = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPickingList)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_cancel
            // 
            this.btn_cancel.Location = new System.Drawing.Point(376, 345);
            this.btn_cancel.Name = "btn_cancel";
            this.btn_cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_cancel.TabIndex = 16;
            this.btn_cancel.Text = "Cancel";
            this.btn_cancel.UseVisualStyleBackColor = true;
            this.btn_cancel.Click += new System.EventHandler(this.btn_cancel_Click);
            // 
            // btn_ok
            // 
            this.btn_ok.Location = new System.Drawing.Point(264, 345);
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.Size = new System.Drawing.Size(75, 23);
            this.btn_ok.TabIndex = 17;
            this.btn_ok.Text = "OK";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // DataGridPickingList
            // 
            this.DataGridPickingList.AllowUserToOrderColumns = true;
            this.DataGridPickingList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridPickingList.Location = new System.Drawing.Point(23, 217);
            this.DataGridPickingList.Name = "DataGridPickingList";
            this.DataGridPickingList.Size = new System.Drawing.Size(612, 101);
            this.DataGridPickingList.TabIndex = 15;
            // 
            // txt_cusadd
            // 
            this.txt_cusadd.Location = new System.Drawing.Point(160, 141);
            this.txt_cusadd.Multiline = true;
            this.txt_cusadd.Name = "txt_cusadd";
            this.txt_cusadd.Size = new System.Drawing.Size(117, 53);
            this.txt_cusadd.TabIndex = 13;
            // 
            // txt_cusname
            // 
            this.txt_cusname.Location = new System.Drawing.Point(161, 109);
            this.txt_cusname.Name = "txt_cusname";
            this.txt_cusname.Size = new System.Drawing.Size(116, 20);
            this.txt_cusname.TabIndex = 14;
            // 
            // txt_salesorderno
            // 
            this.txt_salesorderno.Location = new System.Drawing.Point(376, 71);
            this.txt_salesorderno.Name = "txt_salesorderno";
            this.txt_salesorderno.Size = new System.Drawing.Size(117, 20);
            this.txt_salesorderno.TabIndex = 11;
            // 
            // txt_pickinglistno
            // 
            this.txt_pickinglistno.Location = new System.Drawing.Point(144, 74);
            this.txt_pickinglistno.Name = "txt_pickinglistno";
            this.txt_pickinglistno.Size = new System.Drawing.Size(117, 20);
            this.txt_pickinglistno.TabIndex = 12;
            // 
            // lbl_cusadd
            // 
            this.lbl_cusadd.AutoSize = true;
            this.lbl_cusadd.Location = new System.Drawing.Point(59, 148);
            this.lbl_cusadd.Name = "lbl_cusadd";
            this.lbl_cusadd.Size = new System.Drawing.Size(95, 13);
            this.lbl_cusadd.TabIndex = 9;
            this.lbl_cusadd.Text = "Customer Address:";
            // 
            // lbl_cusname
            // 
            this.lbl_cusname.AutoSize = true;
            this.lbl_cusname.Location = new System.Drawing.Point(59, 109);
            this.lbl_cusname.Name = "lbl_cusname";
            this.lbl_cusname.Size = new System.Drawing.Size(85, 13);
            this.lbl_cusname.TabIndex = 10;
            this.lbl_cusname.Text = "Customer Name:";
            // 
            // lbl_salesorderno
            // 
            this.lbl_salesorderno.AutoSize = true;
            this.lbl_salesorderno.Location = new System.Drawing.Point(290, 74);
            this.lbl_salesorderno.Name = "lbl_salesorderno";
            this.lbl_salesorderno.Size = new System.Drawing.Size(80, 13);
            this.lbl_salesorderno.TabIndex = 8;
            this.lbl_salesorderno.Text = "Sales Order no:";
            // 
            // lbl_pickinglistno
            // 
            this.lbl_pickinglistno.AutoSize = true;
            this.lbl_pickinglistno.Location = new System.Drawing.Point(59, 74);
            this.lbl_pickinglistno.Name = "lbl_pickinglistno";
            this.lbl_pickinglistno.Size = new System.Drawing.Size(79, 13);
            this.lbl_pickinglistno.TabIndex = 7;
            this.lbl_pickinglistno.Text = "Picking List no:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(497, 128);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 18;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // GeneratePickingList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(660, 386);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn_cancel);
            this.Controls.Add(this.btn_ok);
            this.Controls.Add(this.DataGridPickingList);
            this.Controls.Add(this.txt_cusadd);
            this.Controls.Add(this.txt_cusname);
            this.Controls.Add(this.txt_salesorderno);
            this.Controls.Add(this.txt_pickinglistno);
            this.Controls.Add(this.lbl_cusadd);
            this.Controls.Add(this.lbl_cusname);
            this.Controls.Add(this.lbl_salesorderno);
            this.Controls.Add(this.lbl_pickinglistno);
            this.Name = "GeneratePickingList";
            this.Text = "Generate Picking List";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridPickingList)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_cancel;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.DataGridView DataGridPickingList;
        private System.Windows.Forms.TextBox txt_cusadd;
        private System.Windows.Forms.TextBox txt_cusname;
        private System.Windows.Forms.TextBox txt_salesorderno;
        private System.Windows.Forms.TextBox txt_pickinglistno;
        private System.Windows.Forms.Label lbl_cusadd;
        private System.Windows.Forms.Label lbl_cusname;
        private System.Windows.Forms.Label lbl_salesorderno;
        private System.Windows.Forms.Label lbl_pickinglistno;
        private System.Windows.Forms.Button button1;
    }
}

