﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace WindowsMain
{
    public partial class Customer : MetroFramework.Forms.MetroForm
    {
        
        public Customer()
        {
            InitializeComponent();
        }

        string tp;

        public void setcustp(string s)
        {
            tp = s;
        }


        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;

        private void Customer_Load(object sender, EventArgs e)
        {
            txt_telnum.Text = tp;
            con = new SqlConnection("Data Source=HIMATH\\HIMATHSQL;Initial Catalog=adroit_lanka_db;Integrated Security=True");

            SqlDataAdapter sda = new SqlDataAdapter("select isnull(max(cast(cusid as int)),1002)+1 from customer", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txt_cid.Text = dt.Rows[0][0].ToString();

            this.ActiveControl = txt_cusname;
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_cusname.Text))
                MessageBox.Show("CustomerName Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txt_cntfname.Text))
                MessageBox.Show("ContactFName Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txt_cntlname.Text))
                MessageBox.Show("ContactLName Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txt_telnum.Text))
                MessageBox.Show("TelephoneNumber Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txt_addr1.Text))
                MessageBox.Show("AddressLine1 Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txt_addr2.Text))
                MessageBox.Show("AddressLine2 Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else if (string.IsNullOrEmpty(txt_addr3.Text))
                MessageBox.Show("AddressLine3 Field must required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            else
            {
                try
                {
                    con.Open();
                    cmd = new SqlCommand("insert into customer values('" + txt_cid.Text + "','" + txt_cusname.Text + "','" + txt_cntfname.Text + "','" + txt_cntlname.Text + "','" + txt_telnum.Text + "','" + txt_addr1.Text + "','" + txt_addr2.Text + "','" + txt_addr3.Text + "','" + dateTimePicker1.Value + "')", con);
                    int i = cmd.ExecuteNonQuery();
                    if (i == 1)
                        MessageBox.Show("Data insert Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    else
                        MessageBox.Show("Insert is Unsucessfully", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    con.Close();
                    cmd.Dispose();

                }
                catch (SqlException)
                {
                    MessageBox.Show("Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception)
                {
                    MessageBox.Show("Please check again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btn_clr_Click(object sender, EventArgs e)
        {
            txt_cusname.Clear();
            txt_cntfname.Clear();
            txt_cntlname.Clear();
            txt_telnum.Clear();
            txt_addr1.Clear();
            txt_addr2.Clear();
            txt_addr3.Clear();
        }

        private void btn_newentry_Click(object sender, EventArgs e)
        {
            SqlDataAdapter sda = new SqlDataAdapter("select isnull(max(cast(cusid as int)),1002)+1 from customer", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            txt_cid.Text = dt.Rows[0][0].ToString();

            this.ActiveControl = txt_cusname;
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                da = new SqlDataAdapter("Select * from customer ", con);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (SqlException)
            {
                MessageBox.Show("Database Error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception)
            {
                MessageBox.Show("Please check again", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
