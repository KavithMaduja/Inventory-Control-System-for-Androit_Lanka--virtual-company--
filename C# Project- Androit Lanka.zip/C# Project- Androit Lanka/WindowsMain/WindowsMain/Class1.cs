﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace DatabaseClassForDealer
{
    class DatabaseConnector
    {
        SqlConnection Connection;
        SqlCommand Comd;
        SqlDataAdapter Dadap;

        public DatabaseConnector()
        {
            Connection = new SqlConnection("Data Source=HIMATH\\HIMATHSQL;Initial Catalog=adroit_lanka_db;Integrated Security=True");
        }

        public void Open()
        {
            Connection.Open();
        }

        public void Close()
        {
            Connection.Close();
        }

        public int ExecuteQuery(string command)
        {
            int check=0;
            try
            {
                Open();
                Comd = new SqlCommand(command, Connection);
                check = Comd.ExecuteNonQuery();
                Close();
                
            }
            catch(SqlException)
            {
               
                
            }
            return check;
        }

        public DataTable getData(string query)
        {
            Open();
            Dadap = new SqlDataAdapter(query,Connection);
            DataTable QueryResult = new DataTable();
            Dadap.Fill(QueryResult);
            Close();
            return QueryResult;
        } 

    }
}
