﻿namespace WindowsMain
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lbl_rdate = new System.Windows.Forms.Label();
            this.lbl_cntlname = new System.Windows.Forms.Label();
            this.txt_cntlname = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_view = new System.Windows.Forms.Button();
            this.btn_newentry = new System.Windows.Forms.Button();
            this.txt_cntfname = new System.Windows.Forms.TextBox();
            this.lbl_cntfname = new System.Windows.Forms.Label();
            this.txt_addr3 = new System.Windows.Forms.TextBox();
            this.lbl_addr3 = new System.Windows.Forms.Label();
            this.txt_addr2 = new System.Windows.Forms.TextBox();
            this.lbl_addr2 = new System.Windows.Forms.Label();
            this.txt_cusname = new System.Windows.Forms.TextBox();
            this.lbl_cusname = new System.Windows.Forms.Label();
            this.txt_addr1 = new System.Windows.Forms.TextBox();
            this.txt_telnum = new System.Windows.Forms.TextBox();
            this.txt_cid = new System.Windows.Forms.TextBox();
            this.lbl_addr1 = new System.Windows.Forms.Label();
            this.lbl_tellnum = new System.Windows.Forms.Label();
            this.lbl_cid = new System.Windows.Forms.Label();
            this.btn_clr = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(149, 355);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 47;
            // 
            // lbl_rdate
            // 
            this.lbl_rdate.AutoSize = true;
            this.lbl_rdate.Location = new System.Drawing.Point(24, 361);
            this.lbl_rdate.Name = "lbl_rdate";
            this.lbl_rdate.Size = new System.Drawing.Size(72, 13);
            this.lbl_rdate.TabIndex = 46;
            this.lbl_rdate.Text = "Register Date";
            // 
            // lbl_cntlname
            // 
            this.lbl_cntlname.AutoSize = true;
            this.lbl_cntlname.Location = new System.Drawing.Point(24, 180);
            this.lbl_cntlname.Name = "lbl_cntlname";
            this.lbl_cntlname.Size = new System.Drawing.Size(81, 13);
            this.lbl_cntlname.TabIndex = 45;
            this.lbl_cntlname.Text = "Contact LName";
            // 
            // txt_cntlname
            // 
            this.txt_cntlname.Location = new System.Drawing.Point(149, 174);
            this.txt_cntlname.Name = "txt_cntlname";
            this.txt_cntlname.Size = new System.Drawing.Size(100, 20);
            this.txt_cntlname.TabIndex = 44;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(273, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(522, 281);
            this.dataGridView1.TabIndex = 43;
            // 
            // btn_view
            // 
            this.btn_view.Location = new System.Drawing.Point(373, 395);
            this.btn_view.Name = "btn_view";
            this.btn_view.Size = new System.Drawing.Size(75, 23);
            this.btn_view.TabIndex = 42;
            this.btn_view.Text = "View";
            this.btn_view.UseVisualStyleBackColor = true;
            this.btn_view.Click += new System.EventHandler(this.btn_view_Click);
            // 
            // btn_newentry
            // 
            this.btn_newentry.Location = new System.Drawing.Point(243, 395);
            this.btn_newentry.Name = "btn_newentry";
            this.btn_newentry.Size = new System.Drawing.Size(75, 23);
            this.btn_newentry.TabIndex = 41;
            this.btn_newentry.Text = "New Entry";
            this.btn_newentry.UseVisualStyleBackColor = true;
            this.btn_newentry.Click += new System.EventHandler(this.btn_newentry_Click);
            // 
            // txt_cntfname
            // 
            this.txt_cntfname.Location = new System.Drawing.Point(149, 137);
            this.txt_cntfname.Name = "txt_cntfname";
            this.txt_cntfname.Size = new System.Drawing.Size(100, 20);
            this.txt_cntfname.TabIndex = 40;
            // 
            // lbl_cntfname
            // 
            this.lbl_cntfname.AutoSize = true;
            this.lbl_cntfname.Location = new System.Drawing.Point(21, 137);
            this.lbl_cntfname.Name = "lbl_cntfname";
            this.lbl_cntfname.Size = new System.Drawing.Size(81, 13);
            this.lbl_cntfname.TabIndex = 39;
            this.lbl_cntfname.Text = "Contact FName";
            // 
            // txt_addr3
            // 
            this.txt_addr3.Location = new System.Drawing.Point(149, 324);
            this.txt_addr3.Name = "txt_addr3";
            this.txt_addr3.Size = new System.Drawing.Size(100, 20);
            this.txt_addr3.TabIndex = 38;
            // 
            // lbl_addr3
            // 
            this.lbl_addr3.AutoSize = true;
            this.lbl_addr3.Location = new System.Drawing.Point(21, 331);
            this.lbl_addr3.Name = "lbl_addr3";
            this.lbl_addr3.Size = new System.Drawing.Size(70, 13);
            this.lbl_addr3.TabIndex = 37;
            this.lbl_addr3.Text = "Address line3";
            // 
            // txt_addr2
            // 
            this.txt_addr2.Location = new System.Drawing.Point(149, 287);
            this.txt_addr2.Name = "txt_addr2";
            this.txt_addr2.Size = new System.Drawing.Size(100, 20);
            this.txt_addr2.TabIndex = 36;
            // 
            // lbl_addr2
            // 
            this.lbl_addr2.AutoSize = true;
            this.lbl_addr2.Location = new System.Drawing.Point(21, 287);
            this.lbl_addr2.Name = "lbl_addr2";
            this.lbl_addr2.Size = new System.Drawing.Size(70, 13);
            this.lbl_addr2.TabIndex = 35;
            this.lbl_addr2.Text = "Address line2";
            // 
            // txt_cusname
            // 
            this.txt_cusname.Location = new System.Drawing.Point(149, 98);
            this.txt_cusname.Name = "txt_cusname";
            this.txt_cusname.Size = new System.Drawing.Size(100, 20);
            this.txt_cusname.TabIndex = 34;
            // 
            // lbl_cusname
            // 
            this.lbl_cusname.AutoSize = true;
            this.lbl_cusname.Location = new System.Drawing.Point(21, 101);
            this.lbl_cusname.Name = "lbl_cusname";
            this.lbl_cusname.Size = new System.Drawing.Size(82, 13);
            this.lbl_cusname.TabIndex = 33;
            this.lbl_cusname.Text = "Customer Name";
            // 
            // txt_addr1
            // 
            this.txt_addr1.Location = new System.Drawing.Point(149, 247);
            this.txt_addr1.Name = "txt_addr1";
            this.txt_addr1.Size = new System.Drawing.Size(100, 20);
            this.txt_addr1.TabIndex = 32;
            // 
            // txt_telnum
            // 
            this.txt_telnum.Location = new System.Drawing.Point(149, 208);
            this.txt_telnum.Name = "txt_telnum";
            this.txt_telnum.Size = new System.Drawing.Size(100, 20);
            this.txt_telnum.TabIndex = 31;
            // 
            // txt_cid
            // 
            this.txt_cid.Location = new System.Drawing.Point(149, 56);
            this.txt_cid.Name = "txt_cid";
            this.txt_cid.ReadOnly = true;
            this.txt_cid.Size = new System.Drawing.Size(100, 20);
            this.txt_cid.TabIndex = 30;
            // 
            // lbl_addr1
            // 
            this.lbl_addr1.AutoSize = true;
            this.lbl_addr1.Location = new System.Drawing.Point(21, 247);
            this.lbl_addr1.Name = "lbl_addr1";
            this.lbl_addr1.Size = new System.Drawing.Size(70, 13);
            this.lbl_addr1.TabIndex = 29;
            this.lbl_addr1.Text = "Address line1";
            // 
            // lbl_tellnum
            // 
            this.lbl_tellnum.AutoSize = true;
            this.lbl_tellnum.Location = new System.Drawing.Point(21, 211);
            this.lbl_tellnum.Name = "lbl_tellnum";
            this.lbl_tellnum.Size = new System.Drawing.Size(96, 13);
            this.lbl_tellnum.TabIndex = 28;
            this.lbl_tellnum.Text = "Telephone number";
            // 
            // lbl_cid
            // 
            this.lbl_cid.AutoSize = true;
            this.lbl_cid.Location = new System.Drawing.Point(21, 63);
            this.lbl_cid.Name = "lbl_cid";
            this.lbl_cid.Size = new System.Drawing.Size(65, 13);
            this.lbl_cid.TabIndex = 27;
            this.lbl_cid.Text = "Customer ID";
            // 
            // btn_clr
            // 
            this.btn_clr.Location = new System.Drawing.Point(24, 395);
            this.btn_clr.Name = "btn_clr";
            this.btn_clr.Size = new System.Drawing.Size(75, 23);
            this.btn_clr.TabIndex = 26;
            this.btn_clr.Text = "Clear";
            this.btn_clr.UseVisualStyleBackColor = true;
            this.btn_clr.Click += new System.EventHandler(this.btn_clr_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(133, 395);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 25;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 439);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.lbl_rdate);
            this.Controls.Add(this.lbl_cntlname);
            this.Controls.Add(this.txt_cntlname);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btn_view);
            this.Controls.Add(this.btn_newentry);
            this.Controls.Add(this.txt_cntfname);
            this.Controls.Add(this.lbl_cntfname);
            this.Controls.Add(this.txt_addr3);
            this.Controls.Add(this.lbl_addr3);
            this.Controls.Add(this.txt_addr2);
            this.Controls.Add(this.lbl_addr2);
            this.Controls.Add(this.txt_cusname);
            this.Controls.Add(this.lbl_cusname);
            this.Controls.Add(this.txt_addr1);
            this.Controls.Add(this.txt_telnum);
            this.Controls.Add(this.txt_cid);
            this.Controls.Add(this.lbl_addr1);
            this.Controls.Add(this.lbl_tellnum);
            this.Controls.Add(this.lbl_cid);
            this.Controls.Add(this.btn_clr);
            this.Controls.Add(this.btn_add);
            this.Name = "Customer";
            this.Text = "Customer";
            this.Load += new System.EventHandler(this.Customer_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lbl_rdate;
        private System.Windows.Forms.Label lbl_cntlname;
        private System.Windows.Forms.TextBox txt_cntlname;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_view;
        private System.Windows.Forms.Button btn_newentry;
        private System.Windows.Forms.TextBox txt_cntfname;
        private System.Windows.Forms.Label lbl_cntfname;
        private System.Windows.Forms.TextBox txt_addr3;
        private System.Windows.Forms.Label lbl_addr3;
        private System.Windows.Forms.TextBox txt_addr2;
        private System.Windows.Forms.Label lbl_addr2;
        private System.Windows.Forms.TextBox txt_cusname;
        private System.Windows.Forms.Label lbl_cusname;
        private System.Windows.Forms.TextBox txt_addr1;
        private System.Windows.Forms.TextBox txt_telnum;
        private System.Windows.Forms.TextBox txt_cid;
        private System.Windows.Forms.Label lbl_addr1;
        private System.Windows.Forms.Label lbl_tellnum;
        private System.Windows.Forms.Label lbl_cid;
        private System.Windows.Forms.Button btn_clr;
        private System.Windows.Forms.Button btn_add;
    }
}